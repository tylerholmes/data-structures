#include <stdio.h>
#include <cstdlib>
#include <node1.h>
#include <iostream>
using namespace std;
using namespace main_savitch_5;

int main()
{
	// initialize randNum var and head of LL
	int randNum;
	node* head_ptr = new node(0);
	node* cursor;
	node* curr; 
	
	// for loop to create linked list with 20 random nums
	for(int i = 0; i < 19; i++) {
		randNum = rand()%10;
		list_insert(head_ptr, randNum);
	}
	
	// prints LL after being filled with nums
	cout << "Linked list: ";
	for (cursor = head_ptr; cursor != NULL; cursor = cursor->link()) {
		cout << cursor->data() << ", ";
	}
	
	// function to sort LL (selection sort)
	// precondition: head != null
	// postcondition: linked list is sorted via selection sort
	curr = head_ptr;
	curr = curr->link();
	while (cursor != NULL) {
		for (cursor = head_ptr; cursor != NULL; cursor = cursor->link()) {
			if (cursor->data() > curr->data()) {
				curr = cursor;
			}
			else
				curr = curr->link();
		}
		list_head_insert(head_ptr, curr->data());
	}
	
	cout << "\nLinked list after selection sort: ";
	for (cursor = head_ptr; cursor != NULL; cursor = cursor->link()) {
		cout << cursor->data() << ", ";
	}
	
	return EXIT_SUCCESS;
}