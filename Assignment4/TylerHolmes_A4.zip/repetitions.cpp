#include <stdio.h>
#include <cstdlib>
#include <node1.h>
#include <iostream>
using namespace std;
using namespace main_savitch_5;

int main()
{
	// initialize randNum var and head of LL
	int randNum;
	node* head_ptr = new node(0);
	node* cursor;
	node* iterator;
	node* iterator2;
	
	// for loop to create linked list with 20 random nums
	for(int i = 0; i < 19; i++) {
		randNum = rand()%10;
		list_insert(head_ptr, randNum);
	}
	
	// prints LL after being filled with nums
	cout << "Linked list: ";
	for (cursor = head_ptr; cursor != NULL; cursor = cursor->link()) {
		cout << cursor->data() << ", ";
	}
	
	// deletes all repetitions of numbers
	// precondition: head_ptr != 0
	// postcondition: all repetitions are removed from LL
	for (iterator = head_ptr; iterator != NULL; iterator = iterator->link()) {
		for (iterator2 = head_ptr->link(); iterator2 != NULL; iterator2 = iterator2->link()) {
		if (iterator->data() == iterator2->data()) { 
			list_remove(iterator);
			}
		}
	}
	
	cout << "\nLinked list after repititions removed: ";
	for (cursor = head_ptr; cursor != NULL; cursor = cursor->link()) {
		cout << cursor->data() << ", ";
	}
	
	return EXIT_SUCCESS;
}